var p=0;

function setup() {
  createCanvas(600, 600);
  pixelDensity(1);
  noSmooth();
  angleMode(DEGREES);
}

function draw() {
 let X = sin(frameCount)*cos(frameCount/3.5);
  translate(width / 2, height / 2);//
  rotate(frameCount / 100);
  translate(-width / 2, -height / 2);//
  drawingContext.drawImage(this.canvas,0,0,width,height,-15*X,-15*X,width + 15 * 2*X,height + 15 * 2*X); 
  rect(p,45,90,25);
  if (p>=0){
  p=p+100
}
  if (p==600){
  p=0
}
  push();
  fill(62,186,236);
  noStroke();
  rect(width / 2 - 5, height / 2 - 5,10,10);
  pop();

}
